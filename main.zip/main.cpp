#include "Helper/Includes.h"
#include "Tools.h"
#include "imgui/imgui.h"
#include "imgui/backends/imgui_impl_android.h"
#include "imgui/backends/imgui_impl_opengl3.h"
#include "StrEnc.h"
#include "Helper/Items.h"
#include "obfuscate.h"
#include "Helper/json.hpp"
#include "Iconcpp.h"
#include "ImguiPP.h"
#include "Menu.h"
#include "Vector3.hpp"
#include "Font.h"
#include "Quaternion.hpp"
#include "Icon.h"
#include "CN.h"
#include "King.h"
#include "MOHAN_OP/MemoryPatch.h"
#include "Helper/Dobby/dobby.h"

#include <And64InlineHook/And64InlineHook.hpp>

#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <GLES/gl.h>
#include <GLES/glext.h>
#include <GLES/glplatform.h>
#include "base64/base64.h"
#include <cstring>
#include <string.h>
#include "Rect.h"
#include "SDK.hpp"

using json = nlohmann::json;
#define SLEEP_TIME 1000LL / 60LL
using namespace SDK;


#include "xhook/xhook.h"
#include "INJECTOR.h"
#include "INJECTOR2.h"
#include "KGF.h"
#include "Font.h"
ImFont* INJECTOR = nullptr;
ImFont* INJECTOR2 = nullptr;
ImFont* KGF = nullptr;

std::string expiredDate = " 1st login";
std::string name ="";
std::string deviceSlot = "";
std::string status = "";
std::string floating ="";
std::string g_Token, g_Auth;
#include <jni.h>
#include <string>
#include <dlfcn.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdbool.h>
bool Blacksky;
char extra[32];
float FOVSizea = 120;
// ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
// ==https://t.me/+C58mNt1x3gs0ZWU1
#define GNames_Offset 0x78a0af8
#define GEngine_Offset 0xda686f0//ULocalPlayer
#define GEngine_Offset 0xda8dc18//UEngine
#define GUObject_Offset 0xd741460
#define GetActorArray_Offset 0x99ca838
#define GNativeAndroidApp_Offset 0xd4a4778
#define Actors_Offset 0xA0
#define SwapBuffers 0xBC673C0 


#define IM_PI                   3.14159265358979323846f
#define RAD2DEG( x )  ( (float)(x) * (float)(180.f / IM_PI) )
#define DEG2RAD( x ) ( (float)(x) * (float)(IM_PI / 180.f) )

static std::string apk_pkg = "Created by @lord_hydra";

ImColor outlinecolor = IM_COL32(0, 0, 0, 255);

json items_data;
bool bValid = false;
float FOVSizeNew;
std::string errMsg;
uintptr_t UE4;
uintptr_t anogs;
uintptr_t ANOGS;
uintptr_t g_UE4;
uintptr_t anort;
uintptr_t g_anogs;
uintptr_t hdmpve;
android_app *g_App = 0;
ASTExtraPlayerCharacter *g_LocalPlayer = 0;
ASTExtraPlayerController *g_LocalController = 0;
static std::string EXP = " ";
static float Size = 500;
bool HIDEESP = true;
bool Lobby = true;
 bool BypassNHK = true;
 bool WideView = false;
bool initImGui = false;
bool WALLHACK;
bool show_another_window2 = false;
static bool HideWindow = true;

int screenWidth = -1, glWidth, screenHeight = -1, glHeight;
float density = -1;
json mItemData; 
float FOVSize = 160;

float Skill = 4;
float Sland = 15000;
float sinstanthit = 100000;
static bool IgnoreBot = false;
 ImFont* NHKModFont;
enum EAimMode {
    AimBullet = 0,
    Pbullet = 1,
    AimBot = 2
};

enum EAimTarget {
    Head = 0,
    Chest = 1
};

// ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
// ==https://t.me/+C58mNt1x3gs0ZWU1
 
enum EAimBy {
    FOV = 0,
    Distance = 1
};

enum EAimTrigger {
	Shooting = 0,
    None = 1,
    Scoping = 2,
    Both = 3,
    Any = 4
};

std::map<int, bool> Items;
std::map<int, float *> ItemColors;

struct sConfig {
	bool EnimiesAlertNhk;
	bool Ipad;
	float Meter;
    struct sPlayerESP {
        bool ECount;
        bool Line;		
		bool Box;
		bool DistanceMax;
		bool Health;
		bool Skeleton;
		bool Name;
		bool Distance;
		bool TeamID;
		bool Grenade;
		bool Vehicle;
		bool NoBot;
		bool VehicleHP;
		bool VehicleFuel;
	    bool OneClickEsp;	
	    bool Alert;
		bool LootBox;
		bool Radar;
	    bool Flash;
		bool LootBoxItems;	
        bool wideview;
        bool sfps;
		bool AutoFire;
    };
    sPlayerESP PlayerESP{0};

    struct sVehicleESP {
        bool ShowVehicle;
        bool ShowDistance;
    };
    sVehicleESP VehicleESP{0};

    struct sAimMenu {
        bool Enable;
		bool Line;
        bool VisCheck;
        bool IgnoreKnock;
        bool AimBy;
		EAimBy Fovv;
        bool IgnoreBot;
        bool AimPrediction;
        float Cross;
        EAimMode Mode;
        bool RecoilControl;
        bool Position;
		bool IgnoreKnocked;
        float AimSmooth = 2.9;
        EAimTarget Target;
        EAimTrigger Trigger;
        bool RecoilComparison;
        float Recc;
        float RecoilSet = 1.5f;
        float Range = 100.0f;
        float Fov = 180.0f;
        float FireSpeed;
    };
    sAimMenu SilentAim{0};
    sAimMenu AimBot{0};
	
    struct sHighRisk {
        bool Shake;
        bool Recoil;
		bool NoShake;
        bool Instant;
		bool NoRecoil;
		bool SdkFlash;
        bool HitEffect;
		    bool NoFog;
		bool Pokemon;
        bool Flash;
		bool HeadShot;
		bool InstantHit;		
        bool kill;
        bool Parachute;
        bool Damage;
        bool FastCar;
		bool Wide;
	   bool Switch;
        bool WideView;
    };
    sHighRisk HighRisk{0};

    struct sColorsESP {
        float *Line;
        float *Box;
        float *Name;
        float *Distance;
        float *Skeleton;
        float *SkeletonVisible;
        float *BotNn;
	    float *Skeletonbot;
	    float *nonbot;
        float *Skeletonnon;
        float *BotNv;
        float *Fova;
        float *PotNn;
        float *PotNv;
        float *Vehicle;
    };
    sColorsESP ColorsESP{0};
	
	struct sOTHER {
        bool FPS;
        bool HIDEESP;
        bool EXPIRYTIME;
    };
    sOTHER OTHER{0};
};


sConfig Config{0};
#define CREATE_COLOR(r, g, b, a) new float[4] {(float)r, (float)g, (float)b, (float)a};
std::unordered_set<GLuint> playerPrograms;
GLuint playerVertexShader = 0, playerMaskShader = 0;
std::mutex playerProgramsMutex;
std::mutex playerShaderMutex;

 static UEngine *GEngine = 0;
UWorld *GetWorld() {
    while (!GEngine) {
        GEngine = UObject::FindObject<UEngine>("UAEGameEngine Transient.UAEGameEngine_1"); // Auto 
        sleep(1);
    }
    if (GEngine) {
        auto ViewPort = GEngine->GameViewport;

        if (ViewPort) {
   //return {};
            return ViewPort->World;
        }
    }
    return 0;
}



TNameEntryArray *GetGNames() {
    return ((TNameEntryArray *(*)()) (UE4 + GNames_Offset))();
}

std::vector<AActor *> getActors() {
    auto World = GetWorld();
    if (!World)
        return std::vector<AActor *>();

    auto PersistentLevel = World->PersistentLevel;
    if (!PersistentLevel)
        return std::vector<AActor *>();

    auto Actors = *(TArray<AActor *> *)((uintptr_t) PersistentLevel + Actors_Offset);

    std::vector<AActor *> actors;
    for (int i = 0; i < Actors.Num(); i++) {
        auto Actor = Actors[i];
        if (Actor) {
            actors.push_back(Actor);
        }
    }
    return actors;
}
 
struct sRegion {
    uintptr_t start, end;
};

std::vector<sRegion> trapRegions;

bool isObjectInvalid(UObject *obj) {
    if (!Tools::IsPtrValid(obj)) {
        return true;
    }

    if (!Tools::IsPtrValid(obj->ClassPrivate)) {
        return true;
    }

    if (obj->InternalIndex <= 0) {
        return true;
    }

    if (obj->NamePrivate.ComparisonIndex <= 0) {
        return true;
    }

    if ((uintptr_t)(obj) % sizeof(uintptr_t) != 0x0 && (uintptr_t)(obj) % sizeof(uintptr_t) != 0x4) {
        return true;
    }

    if (std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t) obj) >= region.start && ((uintptr_t) obj) <= region.end; }) ||
        std::any_of(trapRegions.begin(), trapRegions.end(), [obj](sRegion region) { return ((uintptr_t) obj->ClassPrivate) >= region.start && ((uintptr_t) obj->ClassPrivate) <= region.end; })) {
        return true;
    }

    return false;
}

typedef void (*ImGuiDemoMarkerCallback)(const char* file, int line, const char* section, void* user_data);
extern ImGuiDemoMarkerCallback  GImGuiDemoMarkerCallback;
extern void* GImGuiDemoMarkerCallbackUserData;
ImGuiDemoMarkerCallback         GImGuiDemoMarkerCallback = NULL;
void* GImGuiDemoMarkerCallbackUserData = NULL;
#define IMGUI_DEMO_MARKER(section)  do { if (GImGuiDemoMarkerCallback != NULL) GImGuiDemoMarkerCallback(__FILE__, __LINE__, section, GImGuiDemoMarkerCallbackUserData); } while (0)
ImGuiStyle& style = ImGui::GetStyle();
static ImGuiStyle ref_saved_style;
 
std::string getObjectPath(UObject *Object) {
    std::string s;
    for (auto super = Object->ClassPrivate; super; super = (UClass *) super->SuperStruct) {
        if (!s.empty())
            s += ".";
        s += super->NamePrivate.GetName();
    }
    return s;
}
 
int32_t ToColor(float *col) {
    return ImGui::ColorConvertFloat4ToU32(*(ImVec4 *) (col));
}



void DrawText(ImDrawList *draw, const std::string &text, const FVector2D &position, ImU32 color, float fontSize)
{
    draw->AddText(NULL, fontSize, {position.X, position.Y}, color, text.c_str());
}

void DrawTextWithBorder(ImDrawList *draw, const std::string &text, const FVector2D &position, ImU32 textColor, ImU32 borderColor, float fontSize)
{
    float borderSize = 1.0f;

    for (int x = -1; x <= 1; ++x)
    {
        for (int y = -1; y <= 1; ++y)
        {
            if (x == 0 && y == 0)
                continue;

            DrawText(draw, text, {position.X + x * borderSize, position.Y + y * borderSize}, borderColor, fontSize);
        }
    }
    DrawText(draw, text, position, textColor, fontSize);
}

FRotator ToRotator(FVector local, FVector target) {
    FVector rotation = UKismetMathLibrary::Subtract_VectorVector(local, target);

    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);

    FRotator newViewAngle = {0};
    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;

    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;

    return newViewAngle;
}

 #define W2S(w, s) UGameplayStatics::ProjectWorldToScreen(localController, w, true, s)

bool isInsideFOVs(int x, int y) {
    if (!FOVSize)
        return true;

    int circle_x = glWidth / 2;
    int circle_y = glHeight / 2;
    int rad = FOVSizea;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

auto GetTargetForAimBot() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();

    auto Actors = getActors();
    auto localPlayer = g_LocalPlayer;
    auto localController = g_LocalController;

    if (localPlayer) {
        for (auto Actor : Actors) {
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Config.AimBot.IgnoreKnocked) {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (Config.AimBot.VisCheck) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }

                if (Config.AimBot.IgnoreBot) {
                    if (Player->bEnsure)
                        continue;
                }

                auto Root = Player->GetBonePos("Root", {});
                auto Head = Player->GetBonePos("Head", {});

                FVector2D RootSc, HeadSc;
                if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                        FVector2D v2Middle = FVector2D((float) (glWidth / 2), (float) (glHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                        float dist = FVector2D::Distance(v2Middle, v2Loc);

                        if (dist < max) {
                            max = dist;
                            result = Player;
                        }
                    }
                }
            }
        }
    }

    return result;
}



auto GetTargetByPussy() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();

    auto GWorld = GetWorld();
    if (GWorld) {
        ULevel *PersistentLevel = GWorld->PersistentLevel;
        if (PersistentLevel) {
            TArray<AActor *> Actors = *(TArray<AActor *> *) ((uintptr_t) PersistentLevel +
                                                             Actors_Offset);


            auto localPlayer = g_LocalPlayer;
            auto localController = g_LocalController;

            if (localPlayer) {
                for (int i = 0; i < Actors.Num(); i++) {
                    auto Actor = Actors[i];
                    if (isObjectInvalid(Actor))
                        continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Config.SilentAim.IgnoreKnocked) {
                    if (Player->Health == 0.0f)
                        continue;
                }
        
                if (Config.SilentAim.IgnoreBot) {
                    if (Player->bIsAI)
                        continue;
                }
                  
                 
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                              continue;
      
                        float dist = g_LocalPlayer->GetDistanceTo(Player);
                             if (dist < max) {
                                 max = dist;
                              result = Player;
                        
							  }
                            }
                        }
                    }
                }
            }
        

    return result;
}


auto GetTargetByCrossDist() {
    ASTExtraPlayerCharacter *result = 0;
    float max = std::numeric_limits<float>::infinity();

    auto Actors = getActors();

    auto localPlayer = g_LocalPlayer;
    auto localController = g_LocalController;

    if (localPlayer) {
        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                auto Player = (ASTExtraPlayerCharacter *) Actor;

                if (Player->PlayerKey == localPlayer->PlayerKey)
                    continue;

                if (Player->TeamID == localPlayer->TeamID)
                    continue;

                if (Player->bDead)
                    continue;

                if (Config.SilentAim.IgnoreKnocked) {
                    if (Player->Health == 0.0f)
                        continue;
                }

                if (Config.SilentAim.VisCheck) {
                    if (!localController->LineOfSightTo(Player, {0, 0, 0}, true))
                        continue;
                }
                if (Config.SilentAim.IgnoreBot) {
                    if (Player->bIsAI)
                        continue;
                }

                auto Root = Player->GetBonePos("Root", {});
                auto Head = Player->GetBonePos("Head", {});

                FVector2D RootSc, HeadSc;
                if (W2S(Root, &RootSc) && W2S(Head, &HeadSc)) {
                    float height = abs(HeadSc.Y - RootSc.Y);
                    float width = height * 0.65f;

                    FVector middlePoint = {HeadSc.X + (width / 2), HeadSc.Y + (height / 2), 0};
                    if ((middlePoint.X >= 0 && middlePoint.X <= glWidth) && (middlePoint.Y >= 0 && middlePoint.Y <= glHeight)) {
                        FVector2D v2Middle = FVector2D((float) (glWidth / 2), (float) (glHeight / 2));
                        FVector2D v2Loc = FVector2D(middlePoint.X, middlePoint.Y);

                        float dist = FVector2D::Distance(v2Middle, v2Loc);

                        if (dist < max) {
                            max = dist;
                            result = Player;
                        }
                    }
                }
            }
        }
    }

    return result;
}







const char *GetVehicleName(ASTExtraVehicleBase *Vehicle) {
    switch (Vehicle->VehicleShapeType) {
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Motorbike_SideCart:
            return "Motorbike";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Dacia:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyDacia:
            return "Dacia";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MiniBus:
            return "Mini Bus";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PickUp01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyPickup:
            return "Pick Up";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Buggy:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyBuggy:
            return "Buggy";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ01:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ02:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAZ03:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUAZ:
            return "UAZ";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_PG117:
            return "PG117";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Aquarail:
            return "Aquarail";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Mirado01:
            return "Mirado";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Rony:
            return "Rony";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Scooter:
            return "Scooter";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowMobile:
            return "Snow Mobile";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_TukTukTuk:
            return "Tuk Tuk";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_SnowBike:
            return "Snow Bike";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Surfboard:
            return "Surf Board";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Snowboard:
            return "Snow Board";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Amphibious:
            return "Amphibious";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_LadaNiva:
            return "Lada Niva";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_UAV:
            return "UAV";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_MegaDrop:
            return "Mega Drop";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini:
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_Lamborghini01:
            return "Lamborghini";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_GoldMirado:
            return "Gold Mirado";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_BigFoot:
            return "Big Foot";
            break;
        case ESTExtraVehicleShapeType::ESTExtraVehicleShapeType__VST_HeavyUH60:
            return "UH60";
            break;
        default:
            return "Vehicle";
            break;
    }
    return "Vehicle";
}


void (*orig_shoot_event)(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, void *unk1, int unk2) = 0;

bool qwcifqvs86y8fify = false;

void shoot_event(USTExtraShootWeaponComponent *thiz, FVector start, FRotator rot, ASTExtraShootWeapon *weapon, int unk1) {
if (qwcifqvs86y8fify) {
  qwcifqvs86y8fify = false;
  g_LocalController->bIsPressingFireBtn = false;
thiz->OwnerShootWeapon->StopFire(EFreshWeaponStateType::FreshWeaponStateType_Idle);
}

        if (Config.SilentAim.Enable) {
ASTExtraPlayerCharacter *Target = GetTargetByPussy();
        if (Target) {
            bool triggerOk = false;
            if (Config.SilentAim.Trigger != EAimTrigger::None) {
                if (Config.SilentAim.Trigger == EAimTrigger::Shooting) {
                    triggerOk = g_LocalPlayer->bIsWeaponFiring;
                } else if (Config.SilentAim.Trigger == EAimTrigger::Scoping) {
                    triggerOk = g_LocalPlayer->bIsGunADS;
                } else if (Config.SilentAim.Trigger == EAimTrigger::Both) {
                    triggerOk = g_LocalPlayer->bIsWeaponFiring && g_LocalPlayer->bIsGunADS;
                } else if (Config.SilentAim.Trigger == EAimTrigger::Any) {
                    triggerOk = g_LocalPlayer->bIsWeaponFiring || g_LocalPlayer->bIsGunADS;
                }
            } else triggerOk = true;
            if (triggerOk) {
                FVector targetAimPos = Target->GetBonePos("Head", {});
                if (Config.SilentAim.Target == EAimTarget::Chest) {
                    targetAimPos.Z -= 25.0f;
                }

                UShootWeaponEntity *ShootWeaponEntityComponent = thiz->ShootWeaponEntityComponent;

				
			
                if (ShootWeaponEntityComponent) {
                    ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                    if (CurrentVehicle) {
                        FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;

                        float dist = g_LocalPlayer->GetDistanceTo(Target);
                        auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;

                        targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel));
                    } else {
                        FVector Velocity = Target->GetVelocity();

                        float dist = g_LocalPlayer->GetDistanceTo(Target);
                        auto timeToTravel = dist / ShootWeaponEntityComponent->BulletRange;

                        targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity, timeToTravel));
                    }
                    FVector fDir = UKismetMathLibrary::Subtract_VectorVector(targetAimPos, start);
                    FRotator sex = UKismetMathLibrary::Conv_VectorToRotator(fDir);
                    rot = sex;
                }
            }
        }
    }
    

    return orig_shoot_event(thiz, start, rot, weapon, unk1);
}
 



FVector WorldToRadar(float Yaw, FVector Origin, FVector LocalOrigin, float PosX, float PosY, Vector3 Size, bool &outbuff) {
 bool flag = false;
 double num = (double)Yaw;
 double num2 = num * 0.017453292519943295;
 float num3 = (float)std::cos(num2);
 float num4 = (float)std::sin(num2);
 float num5 = Origin.X - LocalOrigin.X;
 float num6 = Origin.Y - LocalOrigin.Y;
 struct FVector Xector;
 Xector.X = (num6 * num3 - num5 * num4) / 150.f;
 Xector.Y = (num5 * num3 + num6 * num4) / 150.f;
 struct FVector Xector2;
 Xector2.X = Xector.X + PosX + Size.X / 2.f;
 Xector2.Y = -Xector.Y + PosY + Size.Y / 2.f;
 bool flag2 = Xector2.X > PosX + Size.X;
 if (flag2) {
  Xector2.X = PosX + Size.X;
 }else{
  bool flag3 = Xector2.X < PosX;
  if (flag3) {
   Xector2.X = PosX;
  }
 }
 bool flag4 = Xector2.Y > PosY + Size.Y;
 if (flag4) {
  Xector2.Y = PosY + Size.Y;
 }else{
  bool flag5 = Xector2.Y < PosY;
  if (flag5){
   Xector2.Y = PosY;
  }
 }
 bool flag6 = Xector2.Y == PosY || Xector2.X == PosX;
 if (flag6){
  flag = true;
 }
 outbuff = flag;
 return Xector2;
}


void VectorAnglesRadar(Vector3 & forward, FVector & angles) {
 if (forward.X == 0.f && forward.Y == 0.f) {
  angles.X = forward.Z > 0.f ? -90.f : 90.f;
  angles.Y = 0.f;
 } else {
  angles.X = RAD2DEG(atan2(-forward.Z, forward.Magnitude(forward)));
  angles.Y = RAD2DEG(atan2(forward.Y, forward.X));
 }
 angles.Z = 0.f;
}

void RotateTriangle(std::array<Vector3, 3> & points, float rotation) {
 const auto points_center = (points.at(0) + points.at(1) + points.at(2)) / 3;
 for (auto & point : points) {
  point = point - points_center;
  const auto temp_x = point.X;
  const auto temp_y = point.Y;
  const auto theta = DEG2RAD(rotation);
  const auto c = cosf(theta);
  const auto s = sinf(theta);
  point.X = temp_x * c - temp_y * s;
  point.Y = temp_x * s + temp_y * c;
  point = point + points_center;
 }
 }
 


class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;

public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {
    }

    void update() {
        m_fpscount++;

        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;

            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }

    unsigned int get() const {
        return m_fps;
    }
};

FPSCounter fps;


static float isRed = 0.0f, isGreen = 0.01f, isBlue = 0.0f;
void DrawESP(ImDrawList *draw) {
	
		if (BypassNHK){

	}




 
	            


                         
	static ULocalPlayer *UlocalPlayer = nullptr;
    if (!UlocalPlayer)
    {
        UlocalPlayer = UObject::FindObject<ULocalPlayer>("LocalPlayer Transient.UAEGameEngine_1.LocalPlayer_1");
    }

    if (UlocalPlayer == nullptr)
        return;



    static auto OrigView = UlocalPlayer->AspectRatioAxisConstraint;
    if (Config.HighRisk.Wide)
    {
        UlocalPlayer->AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV;
    }
    else
    {
        if (UlocalPlayer->AspectRatioAxisConstraint != OrigView)
        {
            UlocalPlayer->AspectRatioAxisConstraint = OrigView;
        }
    }
	
	auto isFrames = ImGui::GetFrameCount();
	    if(isFrames % 1 == 0) {

        if(isGreen == 0.01f && isBlue == 0.0f){
            isRed += 0.01f;
             }

        if(isRed > 0.99f && isBlue == 0.0f){
            isRed = 1.0f;
            isGreen += 0.01f;
            }

        if(isGreen > 0.99f && isBlue == 0.0f){
            isGreen = 1.0f;
            isRed -= 0.01f;
        }

       if(isRed < 0.01f && isGreen == 1.0f){
            isRed = 0.0f;
            isBlue += 0.01f;
            }

        if(isBlue > 0.99f && isRed == 0.0f){
            isBlue = 1.0f;
            isGreen -= 0.01f;
            }
        if(isGreen < 0.01f && isBlue == 1.0f){
            isGreen = 0.0f;
            isRed += 0.01f;
            }
        if(isRed > 0.99f && isGreen == 0.0f){
            isRed = 1.0f;
            isBlue -= 0.01f;
            }
        if(isBlue < 0.01f && isGreen == 0.0f){
            isBlue = 0.0f;
            isRed -= 0.01f;
            if(isRed < 0.01f)
            isGreen = 0.01f;
        }
 
    }
	
	

	

    if (Config.OTHER.HIDEESP) {
        HIDEESP = false;
    } else {
        HIDEESP = true;
    }
    if (HIDEESP) {

        auto Actors = getActors();

        int totalEnemies = 0, totalBots = 0;

        ASTExtraPlayerCharacter *localPlayer = 0;
        ASTExtraPlayerController *localController = 0;


        std::string sFPS = "FPS: ";
        sFPS += std::to_string(fps.get());

             if (Config.OTHER.FPS) {
			
            draw->AddText({ ((float) density / 10.0f), 160}, IM_COL32(0,255,0, 255),
			              sFPS.c_str());
        }
		


        for (int i = 0; i < Actors.size(); i++) {
            auto Actor = Actors[i];
            if (isObjectInvalid(Actor))
                continue;

            if (Actor->IsA(ASTExtraPlayerController::StaticClass())) {
                localController = (ASTExtraPlayerController *) Actor;
                break;
            }
        }
		

		
		if (localController ==0){
			draw->AddText({((float) density / 10.0f), 40},IM_COL32(255, 0, 0, 255),sFPS.c_str());
			}else{
            std::string sFPS = "";
            sFPS += std::to_string(fps.get());
            draw->AddText({((float) density / 10.0f), 40},IM_COL32(255, 155, 0, 255),sFPS.c_str());
        }

        if (localController) {
            for (int i = 0; i < Actors.size(); i++) {
                auto Actor = Actors[i];
                if (isObjectInvalid(Actor))
                    continue;

                if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                    if (((ASTExtraPlayerCharacter *) Actor)->PlayerKey ==
                        localController->PlayerKey) {
                        localPlayer = (ASTExtraPlayerCharacter *) Actor;
                        break;
                    }
                }
            }


                            if (localPlayer) {
                    if (localPlayer->PartHitComponent) {
                        auto ConfigCollisionDistSqAngles = localPlayer->PartHitComponent->ConfigCollisionDistSqAngles;
                        for (int j = 0; j < ConfigCollisionDistSqAngles.Num(); j++) {
                            ConfigCollisionDistSqAngles[j].Angle = 180.0f;
                        }
                        localPlayer->PartHitComponent->ConfigCollisionDistSqAngles = ConfigCollisionDistSqAngles;
                    }

					    
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\\


    
                                

                                        if (Config.HighRisk.Recoil || Config.HighRisk.Shake || Config.HighRisk.Instant) {
    auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
    if (WeaponManagerComponent) {
        auto CurrentWeaponReplicated = (ASTExtraShootWeapon *)WeaponManagerComponent->CurrentWeaponReplicated;
        if (CurrentWeaponReplicated) {
            auto ShootWeaponEntityComp = CurrentWeaponReplicated->ShootWeaponEntityComp;
            auto ShootWeaponEffectComp = CurrentWeaponReplicated->ShootWeaponEffectComp;
            if (ShootWeaponEntityComp && ShootWeaponEffectComp) {
                // Recoil Settings
                if (Config.HighRisk.Recoil) {
                    memset(&ShootWeaponEntityComp->RecoilInfo, 0, sizeof(FSRecoilInfo));

                    ShootWeaponEntityComp->AccessoriesVRecoilFactor = 0.01f;
                    ShootWeaponEntityComp->AccessoriesHRecoilFactor = 0.01f;
                    ShootWeaponEntityComp->AccessoriesRecoveryFactor = 0.01f;

                    memset(&ShootWeaponEntityComp->DeviationInfo, 0, sizeof(FSDeviation));

                    ShootWeaponEntityComp->ShotGunCenterPerc = 0.01f;
                    ShootWeaponEntityComp->ShotGunVerticalSpread = 0.01f;
                    ShootWeaponEntityComp->ShotGunHorizontalSpread = 0.01f;

                    ShootWeaponEntityComp->GameDeviationFactor = 0.3f;
                    ShootWeaponEntityComp->GameDeviationAccuracy = 0.01f;

                    ShootWeaponEntityComp->CrossHairInitialSize = 0.01f;
                    ShootWeaponEntityComp->CrossHairBurstSpeed = 0.01f;
                    ShootWeaponEntityComp->CrossHairBurstIncreaseSpeed = 0.01f;
                    ShootWeaponEntityComp->VehicleWeaponDeviationAngle = 0.01f;
                    ShootWeaponEntityComp->RecoilKickADS = 0.01f;
                }

                // Shake Settings
                if (Config.HighRisk.Shake) {
                    ShootWeaponEffectComp->CameraShakeInnerRadius = 0.01f;
                    ShootWeaponEffectComp->CameraShakeOuterRadius = 0.01f;
                    ShootWeaponEffectComp->CameraShakFalloff = 0.01f;					  
                    ShootWeaponEntityComp->AnimationKick = 0.01f;
                }
                           
                      
                   
                       // Hit Effect Settings
                if (Config.HighRisk.HitEffect) {
                    ShootWeaponEntityComp->ExtraHitPerformScale = 50.0f;
                }
}
}

}

}
                // Switch Settings
             

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\\
              static bool bShooting = false;  
        if (Config.SilentAim.Enable) {
	    auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
        if (WeaponManagerComponent) {
        auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
        if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
        auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
        if (CurrentWeaponReplicated) {
        auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
        if (ShootWeaponComponent) {
        int shoot_event_idx = 169;
        auto VTable = (void **) ShootWeaponComponent->VTable;
        auto f_mprotect = [](uintptr_t addr, size_t len,
        int32_t prot) -> int32_t {
        static_assert(PAGE_SIZE == 4096);
        constexpr
        size_t page_size = static_cast<size_t>(PAGE_SIZE);
        void *start = reinterpret_cast<void *>(addr &
        -page_size);
        uintptr_t end =
        (addr + len + page_size - 20) & -page_size;
        return mprotect(start, end -
        reinterpret_cast<uintptr_t>(start),
        prot);
        };
        if (VTable && (VTable[shoot_event_idx] != shoot_event)) {
        orig_shoot_event = decltype(orig_shoot_event)(
        VTable[shoot_event_idx]);
        f_mprotect((uintptr_t)(&VTable[shoot_event_idx]),
        sizeof(uintptr_t), PROT_READ | PROT_WRITE);
        VTable[shoot_event_idx] = (void *) shoot_event;
        }
        }
        }
        }
        }	
        }
		
		                          if (Config.SilentAim.Enable) {
                       auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                    if (WeaponManagerComponent) {
                        auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                        if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
                            auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                            if (CurrentWeaponReplicated) {
                                auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                if (ShootWeaponComponent) {
                                    int shoot_event_idx = 169;
                                    auto VTable = (void **) ShootWeaponComponent->VTable;
                                    // CHANGE22222 add lambda function f_mprotect
                                    auto f_mprotect = [](uintptr_t addr, size_t len, int32_t prot) -> int32_t {
                                      static_assert(PAGE_SIZE == 4096);
                                      constexpr size_t page_size = static_cast<size_t>(PAGE_SIZE);
                                      void* start = reinterpret_cast<void*>(addr & -page_size);
                                      uintptr_t end = (addr + len + page_size - 1) & -page_size;
                                      return mprotect(start, end - reinterpret_cast<uintptr_t>(start), prot);
                                    };
                                    if (VTable && (VTable[shoot_event_idx] != shoot_event)) {
                                        orig_shoot_event = decltype(orig_shoot_event)(
                                                VTable[shoot_event_idx]);
                                        // CHANGE22222 add call of f_mprotect
                                        f_mprotect((uintptr_t)(&VTable[shoot_event_idx]), sizeof(uintptr_t), PROT_READ | PROT_WRITE);
                                        VTable[shoot_event_idx] = (void *) shoot_event;
                                    }
                                }
                            }
                       }
                  }
              
                    	if (Config.PlayerESP.AutoFire) {
  if (GetTargetByPussy()) {
    localController->bIsPressingFireBtn = true;
  } else {
   
    qwcifqvs86y8fify = true;
  }
}
}

		                    //Aimbot//
                    if (Config.AimBot.Enable) {
                    ASTExtraPlayerCharacter *Target = GetTargetForAimBot();
                    if (Target) {
                        bool triggerOk = false;
                            if (Config.AimBot.Trigger != EAimTrigger::Shooting) {
                                triggerOk = localPlayer->bIsWeaponFiring;
                            } else if (Config.AimBot.Trigger == EAimTrigger::Scoping) {
                                triggerOk = localPlayer->bIsGunADS;
                            } else if (Config.AimBot.Trigger == EAimTrigger::Both) {
                                triggerOk = localPlayer->bIsWeaponFiring && localPlayer->bIsGunADS;
                            } else if (Config.AimBot.Trigger == EAimTrigger::Any) {
                                triggerOk = localPlayer->bIsWeaponFiring || localPlayer->bIsGunADS;
                            }
                        else triggerOk = true;
                        if (triggerOk) {
              FVector targetAimPos = Target->GetBonePos("Head", {});
                               if (Config.AimBot.Target == EAimTarget::Chest) {
                                  targetAimPos = Target->GetBonePos("spine_03", {});
                               }
    
                   if (Config.AimBot.Target == EAimTarget::Head) {
                                  targetAimPos = Target->GetBonePos("Head", {});
                              }
           
                            auto WeaponManagerComponent = localPlayer->WeaponManagerComponent;
                            if (WeaponManagerComponent) {
                                auto propSlot = WeaponManagerComponent->GetCurrentUsingPropSlot();
                                if ((int) propSlot.GetValue() >= 1 && (int) propSlot.GetValue() <= 3) {
                                    auto CurrentWeaponReplicated = (ASTExtraShootWeapon *) WeaponManagerComponent->CurrentWeaponReplicated;
                                    if (CurrentWeaponReplicated) {
                                        auto ShootWeaponComponent = CurrentWeaponReplicated->ShootWeaponComponent;
                                        if (ShootWeaponComponent) {
                                            UShootWeaponEntity *ShootWeaponEntityComponent = ShootWeaponComponent->ShootWeaponEntityComponent;
                                            if (ShootWeaponEntityComponent) {
                                                ASTExtraVehicleBase *CurrentVehicle = Target->CurrentVehicle;
                                                if (CurrentVehicle) {
                                                    FVector LinearVelocity = CurrentVehicle->ReplicatedMovement.LinearVelocity;

                                                    float dist = localPlayer->GetDistanceTo(Target);
                                                    auto timeToTravel = dist /
                                                                        ShootWeaponEntityComponent->BulletFireSpeed;

                                                    targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(LinearVelocity, timeToTravel));
                                                    targetAimPos.Z += LinearVelocity.Z * timeToTravel + 0.5 * Config.AimBot.Line * timeToTravel * timeToTravel;
                                                } else {
                                                    FVector Velocity = Target->GetVelocity();

                                                    float dist = localPlayer->GetDistanceTo(Target);
                                                    auto timeToTravel = dist / ShootWeaponEntityComponent->BulletFireSpeed;

                                                    targetAimPos = UKismetMathLibrary::Add_VectorVector(targetAimPos, UKismetMathLibrary::Multiply_VectorFloat(Velocity, timeToTravel));
	targetAimPos.Z += Velocity.Z * timeToTravel + 0.5 * Config.AimBot.Line * timeToTravel * timeToTravel;
                                                }
                                                
                                                if (Config.AimBot.RecoilComparison) {
                                                    if (g_LocalPlayer->bIsGunADS) {
                                                        if (g_LocalPlayer->bIsWeaponFiring) {
                                                            float dist = g_LocalPlayer->GetDistanceTo(Target) / 100.f;                                                                                 
                                                            targetAimPos.Z -= dist * Config.AimBot.Recc;
                                                        }  
                                                    }
                                                }
                                                localController->SetControlRotation(ToRotator(localController->PlayerCameraManager->CameraCache.POV.Location, targetAimPos), "");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                  }	
                  
                   FVector ViewPosY{0, 0, 0};
                        if (localPlayer) {                   
                        ViewPosY = localPlayer->GetBonePos("Head", {});
                        ViewPosY.Z += 10.f;
                         }         
						 
				  

				  
				  				if (Config.HighRisk.SdkFlash) {
                            auto GWorld = GetWorld();GWorld->PersistentLevel->WorldSettings->MinUndilatedFrameTime = 0.100f;
						     }
///                       ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\\



                                           for (auto &i : Actors) {
                auto Actor = i;
                if (isObjectInvalid(Actor))
                    continue;

                if (Actor->IsA(ASTExtraPlayerCharacter::StaticClass())) {
                    auto Player = (ASTExtraPlayerCharacter *) Actor;

                    float Distance = localPlayer->GetDistanceTo(Player) / 100.0f;
                    if (Distance > 800)
                        continue;

                    if (Player->PlayerKey == localController->PlayerKey)
                        continue;

                    if (Player->TeamID == localController->TeamID)
                        continue;

                    if (Player->bDead)
                        continue;

                    if (!Player->Mesh)
                        continue;

                    if (Player->bEnsure)
                        totalBots++;
                    else totalEnemies++;

                    if (Config.PlayerESP.NoBot)
                        if (Player->bEnsure)
                            continue;

                    float magic_number = (Distance);
                    float mx = (glWidth / 4) / magic_number;

                    float healthLength = glWidth / 19;
                    if (healthLength < mx)
                        healthLength = mx;

                    auto HeadPos = Player->GetBonePos("Head", {});
                    ImVec2 HeadPosSC;

                    auto RootPos = Player->GetBonePos("Root", {});
                    ImVec2 RootPosSC;
                    auto upper_r = Player->GetBonePos("upperarm_r", {});
                    ImVec2 upper_rPoSC;
                    auto lowerarm_r = Player->GetBonePos("lowerarm_r", {});
                    ImVec2 lowerarm_rPoSC;
                    auto hand_r = Player->GetBonePos("hand_r", {});
                    ImVec2 hand_rPoSC;
                    auto upper_l = Player->GetBonePos("upperarm_l", {});
                    ImVec2 upper_lPoSC;
                    auto lowerarm_l = Player->GetBonePos("lowerarm_l", {});
                    ImVec2 lowerarm_lSC;
                    auto hand_l = Player->GetBonePos("hand_l", {});
                    ImVec2 hand_lPoSC;
                    auto thigh_l = Player->GetBonePos("thigh_l", {});
                    ImVec2 thigh_lPoSC;
                    auto calf_l = Player->GetBonePos("calf_l", {});
                    ImVec2 calf_lPoSC;
                    auto foot_l = Player->GetBonePos("foot_l", {});
                    ImVec2 foot_lPoSC;
                    auto thigh_r = Player->GetBonePos("thigh_r", {});
                    ImVec2 thigh_rPoSC;
                    auto calf_r = Player->GetBonePos("calf_r", {});
                    ImVec2 calf_rPoSC;
                    auto foot_r = Player->GetBonePos("foot_r", {});
                    ImVec2 foot_rPoSC;
                    auto neck_01 = Player->GetBonePos("neck_01", {});
                    ImVec2 neck_01PoSC;
                    auto pelvis = Player->GetBonePos("pelvis", {});
                    ImVec2 pelvisPoSC;

                    bool IsVisible = localController->LineOfSightTo(Player, {0, 0, 0}, true);

                    int SCOLOR, SCOLOR2;

                    if (IsVisible)
                    {
				        SCOLOR = ToColor(Config.ColorsESP.SkeletonVisible);
                        SCOLOR2 = IM_COL32(0, 255, 0, 255);
                    }else{
                        SCOLOR = ToColor(Config.ColorsESP.Skeleton);
                        SCOLOR2 = IM_COL32(255, 255, 255, 255);
                    }

                    if (W2S(HeadPos, (FVector2D *) &HeadPosSC) &&
                        W2S(upper_r, (FVector2D *) &upper_rPoSC) &&
                        W2S(upper_l, (FVector2D *) &upper_lPoSC) &&
                        W2S(lowerarm_r, (FVector2D *) &lowerarm_rPoSC ) &&
                        W2S(hand_r, (FVector2D *) &hand_rPoSC ) &&
                        W2S(lowerarm_l, (FVector2D *) &lowerarm_lSC ) &&
                        W2S(hand_l, (FVector2D *) &hand_lPoSC ) &&
                        W2S(thigh_l, (FVector2D *) &thigh_lPoSC ) &&
                        W2S(calf_l, (FVector2D *) &calf_lPoSC ) &&
                        W2S(foot_l, (FVector2D *) &foot_lPoSC ) &&
                        W2S(thigh_r, (FVector2D *) &thigh_rPoSC ) &&
                        W2S(calf_r, (FVector2D *) &calf_rPoSC ) &&
                        W2S(foot_r, (FVector2D *) &foot_rPoSC ) &&
                        W2S(neck_01, (FVector2D *) &neck_01PoSC ) &&
                        W2S(pelvis, (FVector2D *) &pelvisPoSC ) &&
                        W2S(RootPos, (FVector2D *) &RootPosSC)){
							
						
                        if (Distance < 800.0f && totalEnemies > 0 || totalBots > 0) {
	
							
                                                           if (Config.PlayerESP.Line) {
                                draw->AddLine({(float) glWidth / 2, 0}, HeadPosSC, SCOLOR2, 1.5f);
                            }
                                                      if (Config.PlayerESP.Box) {
                                                float boxHeight = abs(HeadPosSC.y - RootPosSC.y);
                float boxWidth = boxHeight * 0.65f;
                ImVec2 vStart = {HeadPosSC.x - (boxWidth / 2), HeadPosSC.y};
                ImVec2 vEnd = {vStart.x + boxWidth, vStart.y + boxHeight};

                static float animTime = 0.0f;
                static float animDuration = 1.0f;
                static bool animDirection = true;

                animTime += ImGui::GetIO().DeltaTime;
                if (animTime > animDuration) {
                    animTime = 0.0f;
                    animDirection = !animDirection;
                }

                float animFactor = sin(animTime / animDuration * 3.14159f);

                float r1 = 0.5f + sin(animTime * 2.0f + 0.0f) * 0.5f;
                float g1 = 0.5f + sin(animTime * 2.0f + 2.0944f) * 0.5f;
                float b1 = 0.5f + sin(animTime * 2.0f + 4.1888f) * 0.5f;

                float r2 = 0.5f + sin(animTime * 3.0f + 0.5f) * 0.5f;
                float g2 = 0.5f + sin(animTime * 3.0f + 2.5944f) * 0.5f;
                float b2 = 0.5f + sin(animTime * 3.0f + 4.7888f) * 0.5f;

                float r3 = 0.5f + sin(animTime * 4.0f + 1.0f) * 0.5f;
                float g3 = 0.5f + sin(animTime * 4.0f + 3.0944f) * 0.5f;
                float b3 = 0.5f + sin(animTime * 4.0f + 5.3888f) * 0.5f;

                float r = (r1 + r2 + r3) / 3.0f;
                float g = (g1 + g2 + g3) / 3.0f;
                float b = (b1 + b2 + b3) / 3.0f;

                ImU32 borderColor = ImGui::GetColorU32(ImVec4(r, g, b, 1.0f));
                ImU32 fillColor = ImGui::GetColorU32(ImVec4(r, g, b, 0.2f));

                ImVec2 moveStart = vStart;
                ImVec2 moveEnd = vEnd;
                if (animDirection) {
                    moveStart.x += animFactor * (boxWidth / 2.5f);
                    moveEnd.x -= animFactor * (boxWidth / 2.5f);
                } else {
                    moveStart.x -= animFactor * (boxWidth / 2.5f);
                    moveEnd.x += animFactor * (boxWidth / 2.5f);
                }

                draw->AddRectFilled(moveStart, moveEnd, fillColor, 1.5f, 240);
                draw->AddRect(moveStart, moveEnd, borderColor, 2.5f, 240, 1.7f);
            }
									if (Config.SilentAim.Enable) {
			                  draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), FOVSizeNew, SCOLOR2, 0, 2.5f);;
                               }		
									
                          if (Config.PlayerESP.Skeleton) {
                                draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, neck_01PoSC, SCOLOR2, 1.5f);
                                draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, neck_01PoSC, SCOLOR2, 1.5f);

                                draw->AddLine({upper_rPoSC.x, upper_rPoSC.y}, lowerarm_rPoSC, SCOLOR2, 1.5f);
                                draw->AddLine({lowerarm_rPoSC.x, lowerarm_rPoSC.y}, hand_rPoSC, SCOLOR2 , 1.5f);

                                draw->AddLine({upper_lPoSC.x, upper_lPoSC.y}, lowerarm_lSC, SCOLOR2, 1.5f);
                                draw->AddLine({lowerarm_lSC.x, lowerarm_lSC.y}, hand_lPoSC, SCOLOR2, 1.5f);

                                draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, thigh_lPoSC, SCOLOR2, 1.5f);

                                draw->AddLine({thigh_lPoSC.x, thigh_lPoSC.y}, calf_lPoSC, SCOLOR2, 1.5f);
                                draw->AddLine({calf_lPoSC.x, calf_lPoSC.y}, foot_lPoSC, SCOLOR2, 1.5f);

                                draw->AddLine({thigh_rPoSC.x, thigh_rPoSC.y}, calf_rPoSC, SCOLOR2, 1.5f);
                                draw->AddLine({calf_rPoSC.x, calf_rPoSC.y}, foot_rPoSC, SCOLOR2, 1.5f);

                                draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, pelvisPoSC, SCOLOR2, 1.5f);
                                draw->AddLine({neck_01PoSC.x, neck_01PoSC.y}, HeadPosSC, SCOLOR2, 1.5f);

								}
								
										if(Config.PlayerESP.Alert){
        bool shit = false;
       FVector MyPosition, EnemyPosition;
       ASTExtraVehicleBase * CurrentVehiclea = Player->CurrentVehicle;
       if (CurrentVehiclea) {
        MyPosition = CurrentVehiclea->RootComponent->RelativeLocation;
       } else {
        MyPosition = Player->RootComponent->RelativeLocation;
       }
       ASTExtraVehicleBase * CurrentVehicle = localPlayer->CurrentVehicle;
       if (CurrentVehicle) {
        EnemyPosition = CurrentVehicle->RootComponent->RelativeLocation;
       } else {
        EnemyPosition = localPlayer->RootComponent->RelativeLocation;
       }
       FVector EntityPos = WorldToRadar(localController->PlayerCameraManager->CameraCache.POV.Rotation.Yaw, MyPosition, EnemyPosition, NULL, NULL, Vector3(glWidth, glHeight, 0), shit);
       FVector angle = FVector();
       Vector3 forward = Vector3((float)(glWidth / 2) - EntityPos.X, (float)(glHeight / 2) - EntityPos.Y, 0.0f);
       VectorAnglesRadar(forward, angle);
       const auto angle_yaw_rad = DEG2RAD(angle.Y + 180.f);
       const auto new_point_x = (glWidth / 2) + (55/*alert dist from me*/) / 2 * 8 * cosf(angle_yaw_rad);
       const auto new_point_y = (glHeight / 2) + (55/*alert dist from me*/) / 2 * 8 * sinf(angle_yaw_rad);
       std::array<Vector3, 3> points { Vector3(new_point_x - ((90) / 4 + 3.5f) / 2, new_point_y - ((55) / 4 + 3.5f) / 2, 0.f), Vector3(new_point_x + ((90) / 4 + 3.5f) / 4, new_point_y, 0.f), Vector3(new_point_x - ((90) / 4 + 3.5f) / 2, new_point_y + ((55) / 4 + 3.5f) / 2, 0.f)};
       RotateTriangle(points, angle.Y + 180.f);
       if (Player->bIsAI) {
       draw->AddTriangle(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(0, 255, 0, 255), 1.5f);
       draw->AddTriangleFilled(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(0, 255, 0, 255));
                            } else {
       draw->AddTriangle(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(255, 0, 0, 255), 1.5f);
       draw->AddTriangleFilled(ImVec2(points.at(0).X, points.at(0).Y), ImVec2(points.at(1).X, points.at(1).Y), ImVec2(points.at(2).X, points.at(2).Y), IM_COL32(255, 0, 0, 255));                            
      }
   }


                              if (Config.PlayerESP.Health) {
    int CurHP = std::clamp((int)Player->Health, 0, (int)Player->HealthMax);
    int MaxHP = (int)Player->HealthMax;
    ImU32 HPColor = IM_COL32(0, 255, 0, 200); // Default green

    bool isKnocked = (Player->Health == 0.0f && !Player->bDead);
    if (isKnocked) {
        HPColor = IM_COL32(255, 255, 250, 200); // Pale yellow for knocked
        CurHP = Player->NearDeathBreath;
        if (Player->NearDeatchComponent) {
            MaxHP = Player->NearDeatchComponent->BreathMax;
        }
    } else {
        float healthPercentage = (CurHP / (float)MaxHP) * 100.0f;

        if (healthPercentage >= 70.0f) {
            HPColor = IM_COL32(0, 255, 0, 200); // Green
        } else if (healthPercentage >= 30.0f) {
            HPColor = IM_COL32(255, 165, 0, 255); // Orange
        } else {
            HPColor = IM_COL32(255, 0, 0, 200); // Red
        }
    }

    // Health bar dimensions
    float boxWidth = density / 6.0f;
    boxWidth -= std::min(((boxWidth / 2.0f) / 700.0f) * Distance, boxWidth / 2.0f);
    float boxHeight = boxWidth * 0.15f;

    ImVec2 vStart = { HeadPosSC.x - (boxWidth / 2.0f), HeadPosSC.y - (boxHeight * 2.5f) };
    ImVec2 vEndFilled = { vStart.x + (CurHP * boxWidth / MaxHP), vStart.y + boxHeight };
    ImVec2 vEndRect = { vStart.x + boxWidth, vStart.y + boxHeight };

    // Draw background and filled health
    draw->AddRectFilled(vStart, vEndRect, IM_COL32(0, 0, 0, 150), 0.0f); // Background
    draw->AddRectFilled(vStart, vEndFilled, Player->bIsAI ? IM_COL32(0, 255, 0, 200) : HPColor, 0.0f);
}
	      
                                
                                    if (Config.PlayerESP.TeamID) {
                         float boxWidth = density / 2.0f;
                                               boxWidth -= std::min(
                                               ((boxWidth / 2) / 00.0f) * Distance,
                                               boxWidth / 2);
                                               float boxHeight = boxWidth * 0.19f;
                                               std::string s;
                                               s += std::to_string(Player->TeamID);
                                               draw->AddText(NULL, ((float) density / 30.0f),
                                               {HeadPosSC.x - (boxWidth / 1.7),
                                               HeadPosSC.y - (boxHeight * 1.83f)},
                                               IM_COL32(0, 0, 0, 255),
                                               s.c_str());
                        }

						              if (Config.PlayerESP.Name || Config.PlayerESP.Distance || Config.PlayerESP.Name) {

                                    

                                    


                                                std::string nameText;
                                                std::string distanceText;
if (Config.PlayerESP.Name) {
                                   					            std::string s;                              					
	                  	        if (Player->bEnsure) {								
	                           	s += " ";                               							
		                        s += "Bot";                           
                            	} else {                      
	                            s += Player->PlayerName.ToString();      	
	                            }
                                draw->AddText(NHKModFont,15.f,ImVec2(HeadPosSC.x - 50 - 6, HeadPosSC.y - 55.9 + 4), IM_COL32(255, 255, 255, 255),s.c_str());
				            	}             
							
						

		                            if (Config.PlayerESP.Distance) {
                                        distanceText += (!nameText.empty() ? ("  ") : "") +
                                                                    std::to_string(static_cast<int>(Distance)) + ("m");
                                                }

                                                auto nameTextSize = ImGui::CalcTextSize2(nameText.c_str(), 0, 25.0f);
                                                auto distanceTextSize = ImGui::CalcTextSize2(distanceText.c_str(), 0, 25.0f);

                                                DrawTextWithBorder(draw, nameText, {RootPosSC.x - (nameTextSize.x / 2), RootPosSC.y}, IM_COL32(0, 255, 0, 255), outlinecolor, 25.0f);
                                                DrawTextWithBorder(draw, distanceText, {RootPosSC.x - (distanceTextSize.x / 2), RootPosSC.y + 30}, IM_COL32(225, 225, 225, 255), outlinecolor, 25.0f);
                                            }
                                            
                                        }
 
				
						}
	
	                        
			

                				

                if (Config.PlayerESP.Vehicle) {
                    if (i->IsA(ASTExtraVehicleBase::StaticClass())) {
                        auto Vehicle = (ASTExtraVehicleBase *) i;

                        if (!Vehicle->Mesh)
                            continue;

                        float Distance = Vehicle->GetDistanceTo(localPlayer) / 100.f;

                        FVector2D vehiclePos;
                        if (W2S(Vehicle->K2_GetActorLocation(), &vehiclePos)) {
                            std::string s = "[";
                                s += GetVehicleName(Vehicle);
                            s += "-";
                                s += std::to_string((int) Distance);
                                s += "M]";

                            draw->AddText(NULL, ((float) density / 20.0f), {vehiclePos.X, vehiclePos.Y}, IM_COL32(255, 0, 0, 255), s.c_str());
                        }
                    }
                }

                if (i->IsA(APickUpWrapperActor::StaticClass())) {
                    auto PickUp = (APickUpWrapperActor *) i;
                    if (Items[PickUp->DefineID.TypeSpecificID]) {
                        auto RootComponent = PickUp->RootComponent;
                        if (!RootComponent)
                            continue;

                        float Distance = PickUp->GetDistanceTo(localPlayer) / 100.f;

                        FVector2D itemPos;
                            if (W2S(PickUp->K2_GetActorLocation(), &itemPos)) {
                                std::string s;
                                uint32_t tc = 0xFF000000;

                                for (auto &category: items_data) {
                                    for (auto &item: category["Items"]) {
                                        if (item["itemId"] == PickUp->DefineID.TypeSpecificID) {
                                            s = item["itemName"].get<std::string>();
                                            tc = strtoul(
                                                    item["itemTextColor"].get<std::string>().c_str(),
                                                    0, 16);
                                            break;
                                    }
                                }
                            }

                            s += " - ";
                            s += std::to_string((int) Distance);
                            s += "M]";
							
							draw->AddText(NULL, ((float) density / 20.0f),
                                              {itemPos.X, itemPos.Y}, tc, s.c_str());
                        }
                    }
                }
            }
        }
    }
         

g_LocalController = localController;
g_LocalPlayer = localPlayer;

 if (totalEnemies > 0 || totalBots > 0) {
    std::string combinedText = "PLAYER " + std::to_string((int)totalEnemies) + "|BOT " + std::to_string((int)totalBots);

    float fontSize = ((float)density / 9.0f);
    auto textSize = ImGui::CalcTextSize2(combinedText.c_str(), 0, fontSize);

    ImVec2 textPos = { ((float)glWidth / 2) - (textSize.x / 2), 70 };

    // Black shadow (outline)
    draw->AddText(NULL, fontSize, {textPos.x + 1, textPos.y + 1}, IM_COL32_BLACK, combinedText.c_str());

    // Main red text
    draw->AddText(NULL, fontSize, textPos, IM_COL32(255, 0, 0, 255), combinedText.c_str());
}
            
        }
    }

           }  

	
 
std::string getClipboardText() {
    if (!g_App)
        return "";

    auto activity = g_App->activity;
    if (!activity)
        return "";

    auto vm = activity->vm;
    if (!vm)
        return "";

    auto object = activity->clazz;
    if (!object)
        return "";

    std::string result;

    JNIEnv *env;
    vm->AttachCurrentThread(&env, 0);
    {
        auto ContextClass = env->FindClass("android/content/Context");
        auto getSystemServiceMethod = env->GetMethodID(ContextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");

        auto str = env->NewStringUTF("clipboard");
        auto clipboardManager = env->CallObjectMethod(object, getSystemServiceMethod, str);
        env->DeleteLocalRef(str);

        auto ClipboardManagerClass = env->FindClass("android/content/ClipboardManager");
        auto getText = env->GetMethodID(ClipboardManagerClass, "getText", "()Ljava/lang/CharSequence;");

        auto CharSequenceClass = env->FindClass("java/lang/CharSequence");
        auto toStringMethod = env->GetMethodID(CharSequenceClass, "toString", "()Ljava/lang/String;");

        auto text = env->CallObjectMethod(clipboardManager, getText);
        if (text) {
            str = (jstring) env->CallObjectMethod(text, toStringMethod);
            result = env->GetStringUTFChars(str, 0);
            env->DeleteLocalRef(str);
            env->DeleteLocalRef(text);
        }

        env->DeleteLocalRef(CharSequenceClass);
        env->DeleteLocalRef(ClipboardManagerClass);
        env->DeleteLocalRef(clipboardManager);
        env->DeleteLocalRef(ContextClass);
    }
    vm->DetachCurrentThread();

    return result;
}


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, /*getContentResolver*/ StrEnc("E8X\\7r7ys_Q%JS+L+~", "\x22\x5D\x2C\x1F\x58\x1C\x43\x1C\x1D\x2B\x03\x40\x39\x3C\x47\x3A\x4E\x0C", 18).c_str(), /*()Landroid/content/ContentResolver;*/ StrEnc("8^QKmj< }5D:9q7f.BXkef]A*GYLNg}B!/L", "\x10\x77\x1D\x2A\x03\x0E\x4E\x4F\x14\x51\x6B\x59\x56\x1F\x43\x03\x40\x36\x77\x28\x0A\x08\x29\x24\x44\x33\x0B\x29\x3D\x08\x11\x34\x44\x5D\x77", 35).c_str());
    jclass settingSecureClass = env->FindClass(/*android/provider/Settings$Secure*/ StrEnc("T1yw^BCF^af&dB_@Raf}\\FS,zT~L(3Z\"", "\x35\x5F\x1D\x05\x31\x2B\x27\x69\x2E\x13\x09\x50\x0D\x26\x3A\x32\x7D\x32\x03\x09\x28\x2F\x3D\x4B\x09\x70\x2D\x29\x4B\x46\x28\x47", 32).c_str());
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, /*getString*/ StrEnc("e<F*J5c0Y", "\x02\x59\x32\x79\x3E\x47\x0A\x5E\x3E", 9).c_str(), /*(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;*/ StrEnc("$6*%R*!XO\"m18o,0S!*`uI$IW)l_/_knSdlRiO1T`2sH|Ouy__^}%Y)JsQ:-\"(2_^-$i{?H", "\x0C\x7A\x4B\x4B\x36\x58\x4E\x31\x2B\x0D\x0E\x5E\x56\x1B\x49\x5E\x27\x0E\x69\x0F\x1B\x3D\x41\x27\x23\x7B\x09\x2C\x40\x33\x1D\x0B\x21\x5F\x20\x38\x08\x39\x50\x7B\x0C\x53\x1D\x2F\x53\x1C\x01\x0B\x36\x31\x39\x46\x0C\x15\x43\x2B\x05\x30\x15\x41\x43\x46\x55\x70\x0D\x59\x56\x00\x15\x58\x73", 71).c_str());

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj, env->NewStringUTF(/*android_id*/ StrEnc("ujHO)8OfOE", "\x14\x04\x2C\x3D\x46\x51\x2B\x39\x26\x21", 10).c_str()));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("m5I{GKGWBP-VOxkA", "\x0C\x5B\x2D\x09\x28\x22\x23\x78\x2D\x23\x02\x14\x3A\x11\x07\x25", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*MODEL*/ StrEnc("|}[q:", "\x31\x32\x1F\x34\x76", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(/*android/os/Build*/ StrEnc("0iW=2^>0zTRB!B90", "\x51\x07\x33\x4F\x5D\x37\x5A\x1F\x15\x27\x7D\x00\x54\x2B\x55\x54", 16).c_str());
    jfieldID modelId = env->GetStaticFieldID(buildClass, /*BRAND*/ StrEnc("@{[FP", "\x02\x29\x1A\x08\x14", 5).c_str(), /*Ljava/lang/String;*/ StrEnc(".D:C:ETZ1O-Ib&^h.Y", "\x62\x2E\x5B\x35\x5B\x6A\x38\x3B\x5F\x28\x02\x1A\x16\x54\x37\x06\x49\x62", 18).c_str());

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(/*android/content/Context*/ StrEnc("`L+&0^[S+-:J^$,r9q92(as", "\x01\x22\x4F\x54\x5F\x37\x3F\x7C\x48\x42\x54\x3E\x3B\x4A\x58\x5D\x7A\x1E\x57\x46\x4D\x19\x07", 23).c_str());
    jmethodID getPackageNameId = env->GetMethodID(contextClass, /*getPackageName*/ StrEnc("YN4DaP)!{wRGN}", "\x3E\x2B\x40\x14\x00\x33\x42\x40\x1C\x12\x1C\x26\x23\x18", 14).c_str(), /*()Ljava/lang/String;*/ StrEnc("VnpibEspM(b]<s#[9cQD", "\x7E\x47\x3C\x03\x03\x33\x12\x5F\x21\x49\x0C\x3A\x13\x20\x57\x29\x50\x0D\x36\x7F", 20).c_str());

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(/*java/util/UUID*/ StrEnc("B/TxJ=3BZ_]SFx", "\x28\x4E\x22\x19\x65\x48\x47\x2B\x36\x70\x08\x06\x0F\x3C", 14).c_str());

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass, /*nameUUIDFromBytes*/ StrEnc("P6LV|'0#A+zQmoat,", "\x3E\x57\x21\x33\x29\x72\x79\x67\x07\x59\x15\x3C\x2F\x16\x15\x11\x5F", 17).c_str(), /*([B)Ljava/util/UUID;*/ StrEnc("sW[\"Q[W3,7@H.vT0) xB", "\x5B\x0C\x19\x0B\x1D\x31\x36\x45\x4D\x18\x35\x3C\x47\x1A\x7B\x65\x7C\x69\x3C\x79", 20).c_str());
    jmethodID toStringMethod = env->GetMethodID(uuidClass, /*toString*/ StrEnc("2~5292eW", "\x46\x11\x66\x46\x4B\x5B\x0B\x30", 8).c_str(), /*()Ljava/lang/String;*/ StrEnc("P$BMc' #j?<:myTh_*h0", "\x78\x0D\x0E\x27\x02\x51\x41\x0C\x06\x5E\x52\x5D\x42\x2A\x20\x1A\x36\x44\x0F\x0B", 20).c_str());

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

std::string RSA_Encrypt(const std::string &clear_text, const std::string &pub_key) {
    std::string result;
    BIO *key = BIO_new_mem_buf((unsigned char *) pub_key.c_str(), -1);
    RSA *rsa = RSA_new();
    rsa = PEM_read_bio_RSA_PUBKEY(key, &rsa, NULL, NULL);
    if (!rsa) {
        return "";
    }

    int key_len = RSA_size(rsa);
    int block_len = key_len - 11;

    char *sub_text = new char[key_len + 1];
    memset(sub_text, 0, key_len + 1);
    int ret = 0;
    int pos = 0;
    std::string sub_str;

    while (pos < clear_text.length()) {
        sub_str = clear_text.substr(pos, block_len);
        memset(sub_text, 0, key_len + 1);
        ret = RSA_public_encrypt(sub_str.length(), (const unsigned char *) sub_str.c_str(), (unsigned char *) sub_text, rsa, RSA_PKCS1_PADDING);
        if (ret >= 0) {
            result.append(std::string(sub_text, ret));
        }
        pos += block_len;
    }

    BIO_free_all(key);
    RSA_free(rsa);
    delete[] sub_text;

    return result;
}

std::string RSA_Decrypt(const std::string &cipher_text, const std::string &pub_key) {
    std::string result;
    BIO *key = BIO_new_mem_buf((unsigned char *) pub_key.c_str(), -1);
    RSA *rsa = RSA_new();

    rsa = PEM_read_bio_RSA_PUBKEY(key, &rsa, NULL, NULL);
    if (!rsa) {
        return "";
    }

    int len = RSA_size(rsa);
    char *buf = new char[len + 1];
    memset(buf, 0, len + 1);

    int ret = RSA_public_decrypt(cipher_text.length(), (const unsigned char *) cipher_text.c_str(), (unsigned char *) buf, rsa, RSA_PKCS1_PADDING);
    if (ret >= 0) {
        result.append(std::string(buf, ret));
    }

    free(buf);
    BIO_free_all(key);
    RSA_free(rsa);

    return result;
}

uint8_t PUBLIC_KEY[450] = {0x8D, 0x8D, 0x8D, 0x8D, 0x8D, 0xE2, 0xE5, 0xE7, 0xE9, 0xEE, 0x80, 0xF0, 0xF5, 0xE2, 0xEC, 0xE9, 0xE3, 0x80, 0xEB, 0xE5, 0xF9, 0x8D, 0x8D, 0x8D, 0x8D, 0x8D, 0xAA, 0xED, 0xE9, 0xE9, 0xE2, 0xE9, 0xCA, 0xE1, 0xEE, 0xE2, 0xC7, 0xCB, 0xD1, 0xC8, 0xCB, 0xC9, 0xE7, 0x99, 0xD7, 0x90, 0xE2, 0xE1, 0xF1, 0xE5, 0xE6, 0xE1, 0xE1, 0xEF, 0xE3, 0xE1, 0xF1, 0x98, 0xE1, 0xED, 0xE9, 0xE9, 0xE2, 0xE3, 0xC7, 0xEB, 0xE3, 0xE1, 0xF1, 0xE5, 0xE1, 0x91, 0xD4, 0xCF, 0xEA, 0x96, 0xED, 0x95, 0xCB, 0xF4, 0xEA, 0xCD, 0xCA, 0xE2, 0xC9, 0xE6, 0xD0, 0xFA, 0xCE, 0xC8, 0xC3, 0xAA, 0x96, 0x90, 0xCB, 0x8B, 0xD8, 0xE7, 0xF7, 0xD6, 0xC6, 0xE1, 0xC4, 0xD1, 0xD7, 0xD6, 0xE5, 0xEA, 0xE7, 0xE2, 0xED, 0x95, 0x93, 0xDA, 0xEA, 0x94, 0xCF, 0x99, 0xF9, 0xDA, 0x91, 0xF0, 0xC3, 0x90, 0x94, 0xE6, 0xEA, 0x98, 0xF4, 0xF6, 0xFA, 0xE1, 0xE8, 0xC1, 0x95, 0x8F, 0xCB, 0x96, 0xEA, 0xC8, 0xC7, 0xD0, 0x8F, 0xC7, 0xF3, 0xC6, 0xC7, 0xE1, 0xF6, 0x8F, 0xF0, 0xEB, 0xC1, 0xC5, 0xD8, 0xCA, 0xAA, 0x96, 0x90, 0x94, 0x98, 0xD3,
                           0xEA, 0xCE, 0xC9, 0x8B, 0xF9, 0x97, 0xF8, 0xE2, 0xD2, 0xC8, 0xEE, 0xF9, 0x93, 0xE5, 0xD2, 0xC7, 0xF2, 0xEA, 0x96, 0xED, 0xCF, 0xC5, 0xED, 0xCB, 0xDA, 0xF0, 0xE9, 0xEF, 0xD4, 0xEA, 0xE7, 0xCB, 0x90, 0xC7, 0xD8, 0xEF, 0xF7, 0x95, 0x93, 0xC6, 0xCF, 0x8F, 0xD3, 0xC8, 0xEB, 0xC8, 0xCD, 0xF5, 0xC2, 0x96, 0xC7, 0xC7, 0x90, 0xD0, 0xCE, 0xD6, 0xD0, 0x92, 0xE8, 0xAA, 0x98, 0xE3, 0xE9, 0x97, 0xD2, 0x99, 0xFA, 0xEC, 0xEB, 0x96, 0xC7, 0xF3, 0xF9, 0xC4, 0xF6, 0xD0, 0xD5, 0x98, 0xD4, 0xF9, 0xCA, 0xFA, 0xEC, 0xEE, 0xD1, 0xE6, 0x95, 0xF3, 0xF2, 0xCB, 0xCE, 0xE1, 0xE7, 0xED, 0x92, 0x93, 0xC8, 0xC9, 0x8F, 0xF8, 0x8B, 0xCD, 0xF4, 0x92, 0xF8, 0x93, 0xEC, 0xEF, 0x93, 0xF0, 0x91, 0xC8, 0xCB, 0xC1, 0x8F, 0xC7, 0xF5, 0xCD, 0xF5, 0xEB, 0xC5, 0x95, 0xCF, 0xFA, 0xAA, 0x90, 0x8B, 0xEB, 0xC6, 0xF1, 0x90, 0xF4, 0xCA, 0x96, 0x91, 0xF7, 0xCE, 0xE6, 0x93, 0xE7, 0x92, 0xC1, 0x95, 0xF7, 0xF9, 0xE2, 0xD9, 0x96, 0x8F, 0xCA, 0xE7, 0xE5, 0xDA, 0xC8, 0xF1, 0xC5, 0xEC, 0xC7, 0x95, 0x92, 0x91, 0x90,
                           0xF4, 0x99, 0xD9, 0x91, 0xD3, 0xD8, 0xF6, 0xEC, 0xE5, 0xF6, 0xF6, 0xF6, 0x95, 0xD8, 0xC8, 0xCA, 0xF1, 0xE8, 0xE7, 0xE1, 0xD2, 0x95, 0xD7, 0xC6, 0x97, 0xF1, 0xE9, 0xAA, 0xCD, 0x96, 0xF5, 0xC7, 0xCE, 0xF7, 0xEC, 0xD9, 0xCD, 0x8B, 0xDA, 0xC6, 0x99, 0xE9, 0xCA, 0xC6, 0xC9, 0xCE, 0xE2, 0xC7, 0xF2, 0x99, 0xF0, 0xF4, 0x99, 0xC3, 0xE8, 0xFA, 0xF4, 0x93, 0xD0, 0xC4, 0x8B, 0x97, 0xC9, 0xE1, 0x91, 0xE4, 0xF7, 0x93, 0x92, 0xE3, 0x98, 0xC4, 0xD7, 0xF5, 0xEA, 0xD6, 0xE2, 0xF4, 0xF0, 0xCE, 0xD8, 0xDA, 0xEE, 0xC9, 0xEA, 0x96, 0xCF, 0x96, 0xE2, 0x90, 0xF3, 0xCC, 0xAA, 0xD5, 0xD7, 0xE9, 0xE4, 0xE1, 0xF1, 0xE1, 0xE2, 0xAA, 0x8D, 0x8D, 0x8D, 0x8D, 0x8D, 0xE5, 0xEE, 0xE4, 0x80, 0xF0, 0xF5, 0xE2, 0xEC, 0xE9, 0xE3, 0x80, 0xEB, 0xE5, 0xF9, 0x8D, 0x8D, 0x8D, 0x8D, 0x8D};

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}
 //@Snj___
   std::string Login(const char *user_key) {
        if (!g_App)
            return "Internal Error";
        auto activity = g_App->activity;
        if (!activity)
            return "Internal Error";
        auto vm = activity->vm;
        if (!vm)
            return "Internal Error";
        auto object = activity->clazz;
        if (!object)
            return "Internal Error";
        JNIEnv *env;
        vm->AttachCurrentThread(&env, 0);
        std::string hwid = user_key;
        hwid += GetAndroidID(env, object);
        hwid += GetDeviceModel(env);
        hwid += GetDeviceBrand(env);
        std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
        vm->DetachCurrentThread();
        std::string errMsg;
        struct MemoryStruct chunk{};
        chunk.memory = (char *) malloc(1);
        chunk.size = 0;
        CURL *curl;
        CURLcode res;
        curl = curl_easy_init();
        if (curl) {
   
        
         std::string CRACKSNIPER = OBFUSCATE("https://rznhack.suhani.site/connect") ;
		 curl_easy_setopt(curl, CURLOPT_PINNEDPUBLICKEY, "sha256//eE5I+2/BIFu1PAhVYMyikqP52HfFssunm9gvAdd3Rlw=");
        curl_easy_setopt(curl, CURLOPT_URL, CRACKSNIPER.c_str());
        
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, /*https*/ StrEnc("!mLBO", "\x49\x19\x38\x32\x3C", 5).c_str());
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, /*Content-Type: application/x-www-form-urlencoded*/ StrEnc("@;Ls\\(KP4Qrop`b#d3094/r1cf<c<=H)AiiBG6i|Ta66s2[", "\x03\x54\x22\x07\x39\x46\x3F\x7D\x60\x28\x02\x0A\x4A\x40\x03\x53\x14\x5F\x59\x5A\x55\x5B\x1B\x5E\x0D\x49\x44\x4E\x4B\x4A\x3F\x04\x27\x06\x1B\x2F\x6A\x43\x1B\x10\x31\x0F\x55\x59\x17\x57\x3F", 47).c_str());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        char data[4096];
        sprintf(data, /*game=PUBG&user_key=%s&serial=%s*/ StrEnc("qu2yXK,YkJyGD@ut0.u~Nb'5(:.:chK", "\x16\x14\x5F\x1C\x65\x1B\x79\x1B\x2C\x6C\x0C\x34\x21\x32\x2A\x1F\x55\x57\x48\x5B\x3D\x44\x54\x50\x5A\x53\x4F\x56\x5E\x4D\x38", 31).c_str(), user_key, UUID.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);

        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

        res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                json result = json::parse(chunk.memory);
                if (result[/*status*/ StrEnc("(>_LBm", "\x5B\x4A\x3E\x38\x37\x1E", 6).c_str()] == true) {
                    std::string token = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*token*/ StrEnc("{>3Lr", "\x0F\x51\x58\x29\x1C", 5).c_str()].get<std::string>();
                    time_t rng = result[/*data*/ StrEnc("fAVA", "\x02\x20\x22\x20", 4).c_str()][/*rng*/ StrEnc("+n,", "\x59\x00\x4B", 3).c_str()].get<time_t>();
	
                    if (rng + 30 > time(0)) {
                        std::string auth = /*PUBG*/ StrEnc("Q*) ", "\x01\x7F\x6B\x67", 4).c_str();;
                        auth += "-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
                        auth += /*Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E*/ StrEnc("-2:uwZdV^%]?{{wHs2V,+(^NJU;kC*_{", "\x7B\x5F\x02\x39\x1C\x6D\x31\x3C\x6C\x6F\x30\x4C\x11\x38\x27\x1E\x23\x64\x3C\x5E\x67\x49\x69\x34\x2D\x33\x43\x58\x36\x50\x66\x3E", 32).c_str();
                        std::string outputAuth = Tools::CalcMD5(auth);
     
                        g_Token = token;
                        g_Auth = outputAuth;
				
                        bValid = g_Token == g_Auth;
				
                    }
                } else {
                    errMsg = result[/*reason*/ StrEnc("LW(3(c", "\x3E\x32\x49\x40\x47\x0D", 6).c_str()].get<std::string>();
                }
            } catch (json::exception &e) {
                errMsg = "{";
                errMsg += e.what();
                errMsg += "}\n{";
                errMsg += chunk.memory;
                errMsg += "}";
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
    }
        curl_easy_cleanup(curl);
        vm->DetachCurrentThread();
        return bValid ? "OK" : errMsg;
    }

//@snj____
//@snj____
void DrawTextCentered(const char *text)
{
    ImGui::Separator();
    ImGui::SetCursorPosX((ImGui::GetWindowWidth() - ImGui::CalcTextSize(text).x) / 5.f);
    ImGui::Text(text);
    ImGui::Separator();
}
 
#define IM_CLAMP(V, MN, MX)     ((V) < (MN) ? (MN) : (V) > (MX) ? (MX) : (V))
namespace Settings
{
    static int Tab = 1;
}

EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);

EGLBoolean _eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    if (glWidth <= 0 || glHeight <= 0)
        return orig_eglSwapBuffers(dpy, surface);

    if (!g_App)
        return orig_eglSwapBuffers(dpy, surface);

    screenWidth = ANativeWindow_getWidth(g_App->window);
    screenHeight = ANativeWindow_getHeight(g_App->window);
    density = AConfiguration_getDensity(g_App->config);


                        if (!initImGui) {
            ImGui::CreateContext();
            ImGuiStyle *style = &ImGui::GetStyle();                   
            style->WindowPadding = ImVec2(12, 12);
            style->WindowRounding = 15.9f;
            style->FramePadding = ImVec2(3, 3);
            style->FrameRounding = 11.0f;
		    style->FrameBorderSize = 5.0f;
		    style->WindowBorderSize = 5.0f;
			style->TabRounding = 2.0f;
					
        style->WindowTitleAlign = ImVec2(0.5, 0.5);
		style->ButtonTextAlign = ImVec2(0.5,0.5);
		style->Colors[ImGuiCol_Text]                  = ImColor(255, 255, 255, 255);
	    style->Colors[ImGuiCol_WindowBg]              = ImColor(0, 0, 0, 20);
	    style->Colors[ImGuiCol_Border]                = ImColor(235, 172, 14, 255);
        style->Colors[ImGuiCol_FrameBg]               = ImColor(0, 0, 0, 255);
		style->Colors[ImGuiCol_FrameBgActive]               = ImColor(0, 0, 0, 255);
		style->Colors[ImGuiCol_FrameBgHovered]               = ImColor(0, 0, 0, 255);
	    style->Colors[ImGuiCol_PopupBg]               = ImColor(0, 0, 0, 20);
		style->Colors[ImGuiCol_Button]                   = ImColor(0, 0, 0, 255);
		style->Colors[ImGuiCol_ButtonActive]             = ImColor(0, 0, 0, 255);
		style->Colors[ImGuiCol_ButtonHovered]            = ImColor(0, 0, 0, 255);
        style->Colors[ImGuiCol_TitleBg]               = ImColor(0, 0, 255, 255);
        style->Colors[ImGuiCol_TitleBgActive]         = ImColor(0, 0, 255, 255);
        style->Colors[ImGuiCol_TitleBgCollapsed]      = ImColor(0, 0, 255, 255);
	    style->Colors[ImGuiCol_CheckMark]             = ImColor(255, 255, 255, 255);
        style->ScaleAllSizes(std::max(2.5f, density / 400.0f));
        style->ScrollbarSize /= 1;       
        ImGui_ImplAndroid_Init();
        ImGui_ImplOpenGL3_Init("#version 300 es");
            ImGuiIO &io = ImGui::GetIO();

            io.ConfigWindowsMoveFromTitleBarOnly = true;
            io.IniFilename = NULL;

            static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
            ImFontConfig icons_config;

            ImFontConfig CustomFont;
            CustomFont.FontDataOwnedByAtlas = false;

            icons_config.MergeMode = true;
            icons_config.PixelSnapH = true;
            icons_config.OversampleH = 2.5;
            icons_config.OversampleV = 2.5;
            
  io.Fonts->AddFontFromMemoryTTF((void *)BaiduZY_data, BaiduZY_size, 23.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
		  io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 28.0f, &icons_config, icons_ranges);
		  io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 24.f, &CustomFont);
		  INJECTOR = io.Fonts->AddFontFromMemoryTTF((void *)INJECTOR_data, INJECTOR_size, 20.5f, NULL, io.Fonts->GetGlyphRangesChineseFull());
	      INJECTOR2 = io.Fonts->AddFontFromMemoryTTF((void *)INJECTOR2_data, INJECTOR2_size, 20.5f, NULL, io.Fonts->GetGlyphRangesChineseFull());
		  KGF = io.Fonts->AddFontFromMemoryTTF((void *)KGF_data, KGF_size, 20.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
          memset(&Config, 0, sizeof(sConfig));

// ===============================ESPCOLOR ================================== // 

        Config.ColorsESP.Line = CREATE_COLOR(255, 0, 0, 255);
        Config.ColorsESP.Box = CREATE_COLOR(0, 0, 139, 255);
        Config.ColorsESP.Name = CREATE_COLOR(255, 0, 0, 255);
        Config.ColorsESP.Vehicle = CREATE_COLOR(255, 0, 0, 255);
	    Config.ColorsESP.Skeletonbot = CREATE_COLOR(255, 0, 0, 255);
        Config.ColorsESP.BotNv = CREATE_COLOR(255, 255, 0, 255);
           Config.ColorsESP.BotNn = CREATE_COLOR(255, 0, 0, 255);
           Config.ColorsESP.Skeletonnon = CREATE_COLOR(255, 0, 255, 255);
           Config.ColorsESP.PotNv = CREATE_COLOR(0, 255, 0, 255);
           Config.ColorsESP.PotNn = CREATE_COLOR(255, 0, 0, 255);
		   Config.ColorsESP.nonbot = CREATE_COLOR(150, 150, 150, 255);
           Config.ColorsESP.SkeletonVisible = CREATE_COLOR(0, 255, 0, 255);
           Config.ColorsESP.Skeleton = CREATE_COLOR(0, 0, 255, 255);
		   Config.ColorsESP.Fova = CREATE_COLOR(255, 255, 255, 255);
		   
           initImGui = true;
        }

        ImGuiIO &io = ImGui::GetIO();
 
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(glWidth, glHeight);
    ImGui::NewFrame();
 
    DrawESP(ImGui::GetBackgroundDrawList());
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ //
        ImGui::SetNextWindowSize(ImVec2((float) glWidth * 0.42f, (float) glHeight * 0.68f), ImGuiCond_Once);
        if (ImGui::Begin(OBFUSCATE("HYDRAxRZN_360°_BT_SERVER" ), 0, ImGuiWindowFlags_NoBringToFrontOnFocus )) {

        static bool isLogin = false;

        if (!isLogin) {
		
			
            ImGui::Text("Please Login");
            ImGui::PushItemWidth(-1);
            static char s[64];
            ImGui::InputText("##key", s, sizeof s);
            ImGui::PopItemWidth();

            if (ImGui::Button(" Paste Key ", ImVec2(ImGui::GetContentRegionAvailWidth(), 0))) {
                auto key = getClipboardText();
                strncpy(s, key.c_str(), sizeof s);
            }

            static std::string err;
            if (ImGui::Button(" Login ", ImVec2(ImGui::GetContentRegionAvailWidth(), 0))) {
                err = Login(s);
                if (err == "OK") {
                    isLogin = bValid && g_Auth == g_Token;
                }
            }

            if (!err.empty() && err != "OK") {
                ImGui::Text("Error: %s", err.c_str());
            }

            } else{
				
						if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {//Enc
            if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {//Enc
              
}
}
				
            
							ImGui::Columns(2);
            ImGui::SetColumnOffset(1, 240);
            {
				
				
				 if (ImGui::Button("VISUAL", ImVec2(225,60)))
                    Settings::Tab = 1;
					
					
					if (ImGui::Button("AIM MENU", ImVec2(225,60)))
                    Settings::Tab = 2;
                
					
					if (ImGui::Button("BRUTAL MENU", ImVec2(225,60)))
                    Settings::Tab = 3;
					
					
					if (ImGui::Button("ITEMS MENU", ImVec2(225,60)))
                    Settings::Tab = 4;
					
					if (ImGui::Button("SONG+IPAD", ImVec2(225,60)))
                    Settings::Tab = 5;
					
				
				
				ImGui::Spacing(); 
				ImGui::Spacing(); 
				ImGui::Spacing(); 
				ImGui::Spacing(); 
				ImGui::Spacing(); 
				ImGui::Text(ICON_FA_TELEGRAM" JOIN TELEGRAM");
				ImGui::Text("       @lord_hydra");
				    }
            ImGui::NextColumn();

// ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
// ==https://t.me/+C58mNt1x3gs0ZWU1
			
			                       if (Settings::Tab == 1) {
									   
									ImGui::RadioButton((" Logo Bypass [ Running... ]"), &BypassNHK);
  		                            // ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
					               if (ImGui::BeginTable("split", 2));
							        {
				                    Config.PlayerESP.Line = true;
Config.PlayerESP.Box = true;
Config.PlayerESP.Skeleton = true;
Config.PlayerESP.Health = true;
Config.PlayerESP.Name = true;
Config.PlayerESP.Distance = true;
Config.PlayerESP.TeamID = true;
Config.EnimiesAlertNhk = true;
Config.PlayerESP.Grenade = true;
Config.PlayerESP.LootBox = true;
Config.PlayerESP.Vehicle = true;
Config.PlayerESP.Alert = true;
Config.PlayerESP.Grenade = true;
			
						
}
                                    ImGui::EndTable();	
				
				 } else if (Settings::Tab == 2) {
// ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
// ==https://t.me/+C58mNt1x3gs0ZWU1
				 
				 
				            ImGui::Checkbox("360 Bullet Track", &Config.SilentAim.Enable);
				            ImGui::Checkbox("Auto fire", &Config.PlayerESP.AutoFire);
							
							if (Config.SilentAim.Enable){
							ImGui::Text("Target Aim : ");
							ImGui::PushItemWidth(500);
                            static const char *targets[] = {"Head", "Chest"};
                            ImGui::Combo("##Target", (int *) &Config.SilentAim.Target,
                            targets, 2, -1);
							ImGui::PopItemWidth();
										ImGui::Spacing();
										ImGui::Text("TARGET");
				ImGui::SliderFloat(" ", &FOVSizeNew, 0.0f, 500.0f);
				ImGui::SameLine();
				ImGui::ColorEdit3("##FovCol", Config.ColorsESP.Fova, ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_NoInputs);
							
							ImGui::Checkbox("Ignore Knocked(Use it)",&Config.SilentAim.IgnoreKnocked);
                            ImGui::Checkbox("Visibility Check",&Config.SilentAim.VisCheck);
                            ImGui::Checkbox("Ignore Bot(Use it)",&Config.SilentAim.IgnoreBot);
				
	

			}
							
							

							
							ImGui::Spacing();
							ImGui::Spacing();
							ImGui::Spacing();
							
							ImGui::Separator();
							ImGui::Separator();
							
							ImGui::Text("                                  AimBot");
				ImGui::Checkbox("ENABLE AIM BOT", &Config.AimBot.Enable);
                          if(Config.AimBot.Enable){
							  	ImGui::Checkbox("RECOIL CONTROL", &Config.AimBot.RecoilComparison); 
					ImGui::SliderFloat("##1", &Config.AimBot.Recc, 0.f, 2.f);		    
				    
						  }
                        ImGui::Text("TargetAimbot     :");
                        ImGui::SameLine();
                        static const char *targetsAimbot[] = {"Head", "Chest"};
                        ImGui::Combo("##TargetAimbot", (int *) &Config.AimBot.Target, targetsAimbot, 2, -1);

                        ImGui::Text("TriggerAimbot    : ");
                        ImGui::SameLine();
                        static const char *triggersAimbot[] = {"None", "Shooting", "Scoping",
                                                         "Both (Shooting & Scoping)",
                                                         "Any (Shooting / Scoping)"};
                        ImGui::Combo("##TriggerAimbot", (int *) &Config.AimBot.Trigger, triggersAimbot, 5, -1);

                        ImGui::Checkbox("IGNORE KNOCK", &Config.AimBot.IgnoreKnocked);
                        ImGui::Checkbox("VISIBILITY CHECK", &Config.AimBot.VisCheck);
                        ImGui::Checkbox("IGNORE KNOCK", &Config.AimBot.IgnoreBot);
							  
// ========  https://t.me/+C58mNt1x3gs0ZWU1  ======= //
// ==https://t.me/+C58mNt1x3gs0ZWU1
                               
								            } else if (Settings::Tab == 3) {
												ImGui::Checkbox("No Recoil", &Config.HighRisk.Recoil);
									 ImGui::Checkbox("No Shake", &Config.HighRisk.Shake);
												//		 ImGui::Checkbox("No Recoil", &Config.HighRisk.Recoil);
								//	ImGui::Checkbox("No Shake", &Config.HighRisk.Shake);
									ImGui::Checkbox("X HitEffect", &Config.HighRisk.HitEffect);
								 
								ImGui::Checkbox("BAN AAYEGA MADARCHOD MAT KAR ON", &Config.HighRisk.SdkFlash);
ImGui::Checkbox("NO FOG", &Config.HighRisk.NoFog);
			
										   } else if (Settings::Tab == 4) {
                                                
							for (auto &i : items_data) {
                        if (ImGui::TreeNode(i["Category"].get<std::string>().c_str())) {
                            for (auto &item : i["Items"]) {
                                ImGui::Checkbox(item["itemName"].get<std::string>().c_str(), (bool *) &Items[item["itemId"].get<int>()]);
                            }
                            ImGui::TreePop();
                        }
                        }
			            }
			  
    }
    }


   ImGui::End();
    ImGui::Render();


        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

return orig_eglSwapBuffers(dpy, surface);
    }

int32_t (*orig_onInputEvent)(struct android_app *app, AInputEvent *inputEvent);

    int32_t onInputEvent(struct android_app *app, AInputEvent *inputEvent) {
        if (initImGui) {
            ImGui_ImplAndroid_HandleInputEvent(inputEvent, {(float) screenWidth / (float) glWidth, (float) screenHeight / (float) glHeight});
        }
        return orig_onInputEvent(app, inputEvent);
    }
    

#define SLEEP_TIME 1000LL / 60LL


        [[noreturn]] void *ipad_thread(void *) {
        while (true) {
        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        if (Config.Ipad) {
        auto objs = UObject::GetGlobalObjects();
        for (int i = 0; i < objs.Num(); i++) {
        auto Object = objs.GetByIndex(i);
        if (isObjectInvalid(Object))
                continue;

				    if (Config.HighRisk.NoFog) {
    if (Object->IsA(UExponentialHeightFogComponent::StaticClass())) {            
    auto playerChar = (UExponentialHeightFogComponent *) Object;
    playerChar->SetStartDistance(0);
    playerChar->SetFogMaxOpacity(0);
    playerChar->SetFogHeightFalloff(0);
    playerChar->SetFogDensity(0);
    playerChar->SetFogCutoffDistance(0); 
    }}
	
          if (Object->IsA(ULocalPlayer::StaticClass())) {
          auto playerChar = (ULocalPlayer *) Object;      
          playerChar->AspectRatioAxisConstraint = EAspectRatioAxisConstraint::AspectRatio_MaintainYFOV;
     }     
     }
     }
         auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
         std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td),SLEEP_TIME)));
     }
     }

    [[noreturn]] void *maps_thread(void *) {
        while (true) {
            auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
	  
            std::vector<sRegion> tmp;
            char line[512];
            FILE *f = fopen("/proc/self/maps", "r");
            if (f) {
                while (fgets(line, sizeof line, f)) {
                    uintptr_t start, end;
                    char tmpProt[16];
                    if (sscanf(line, "%" PRIXPTR "-%" PRIXPTR " %16s %*s %*s %*s %*s", &start, &end, tmpProt) > 0) {
                        if (tmpProt[0] != 'r') {
                            tmp.push_back({start, end});
                        }
                    }
                }
                fclose(f);
            }
            trapRegions = tmp;
        
            auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
            std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
        }
    }
 
 

void FixGameCrash()
{
    system("rm -rf /data/data/com.pubg.imobile/files/ano_tmp");
    system("touch /data/data/com.pubg.imobile/files/ano_tmp");
    system("chmod 000 /data/data/com.pubg.imobile/files/ano_tmp");
}


//Credit | Author [ TG PUSHPARAJTHARKI ] 
void* main_thread(void*) {
	FixGameCrash();
		UE4 = Tools::GetBaseAddress("libUE4.so");
    while (!UE4) {
        UE4 = Tools::GetBaseAddress("libUE4.so");
        sleep(1);
		}
    while (!g_App) {
        g_App = *(android_app **) (UE4 + GNativeAndroidApp_Offset);
        sleep(1);
    }
    while (!g_App->onInputEvent)
        sleep(1);
    orig_onInputEvent = decltype(orig_onInputEvent)(g_App->onInputEvent);
    g_App->onInputEvent = onInputEvent;


//Credit | Author [ TG PUSHPARAJTHARKI ] 

	FName::GNames = GetGNames();
        while (!FName::GNames) {
            FName::GNames = GetGNames();
            sleep(1); }
         UObject::GUObjectArray = (FUObjectArray *) (UE4 + GUObject_Offset);

    xhook_register(".*\\.so$", "eglSwapBuffers", (void*)_eglSwapBuffers, (void **)&orig_eglSwapBuffers);
    xhook_refresh(0);

        pthread_t t;
        pthread_create(&t, 0, maps_thread, 0);

        items_data = json::parse(JSON_ITEMS);

        return 0;
    }

    __attribute__((constructor)) void _init() {
        pthread_t t;
        pthread_create(&t, 0, main_thread, 0);
    }
    
extern "C" JNIEXPORT jstring JNICALL
Java_androidx_multidex_MultiDexApplication_Getproes(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(apk_pkg.c_str());
}
